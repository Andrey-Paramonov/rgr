from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='reg'),
    path('login/', views.login_view, name='log'),
    path('logaut/', views.logut, name='logaut'),
]
