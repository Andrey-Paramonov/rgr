from django.apps import AppConfig


class CkukingConfig(AppConfig):
    name = 'ckuking'
