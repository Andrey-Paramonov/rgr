from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate

def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password != password2:
            messages.error(request, 'Пароли не совпадают')
            return redirect('reg')
            
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Почта занята')
            return redirect('reg')
            
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Этот логин уже занят')
            return redirect('reg')

        user = User.objects.create_user(
            username=username,
            password=password,
            email=email
        )
        auth_login(request, user)
        return redirect('index')
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            auth_login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Неверный логин или пароль')
            return redirect('log')
            
    return render(request, 'login.html')

def logut(request):
    auth_logout(request)
    return redirect('index')
