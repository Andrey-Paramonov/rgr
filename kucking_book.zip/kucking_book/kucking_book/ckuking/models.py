from django.db import models

class User(models.Model):
    name = models.CharField(max_length=250, verbose_name='Имя')
    username = models.CharField(max_length=250, verbose_name='Имя пользователя')
    phone = models.CharField(max_length=250,  verbose_name='Номер телефона')
    email = models.EmailField(max_length=250,  verbose_name='Электронная почта')
    password = models.CharField(max_length=250, blank=False, verbose_name='Пароль')

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

class Recipes(models.Model):
    name = models.CharField(max_length=250, verbose_name='Наименование рецепта')
    image = models.ImageField(upload_to='products/', verbose_name='Фотография блюда')
    ingredients = models.CharField(max_length=250, verbose_name='Ингредиенты')

    class Meta:
        verbose_name = 'Рецепт'
        verbose_name_plural = 'Рецепты'

class Category(models.Model):
    name = models.CharField(max_length=250, verbose_name='Название категории')
    desc = models.CharField(max_length=250, verbose_name='Описание')
    time = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'